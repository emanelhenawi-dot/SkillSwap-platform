import mongoose from 'mongoose';
const { Schema } = mongoose;

const paymentOrderSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  packageId: { type: String, required: true },
  credits: { type: Number, required: true, min: 1 },
  amountEGP: { type: Number, required: true, min: 1 },
  provider: { type: String, enum: ['paymob', 'fawry'], required: true },
  providerOrderId: { type: String, default: null },
  providerTransactionId: { type: String, default: null },
  checkoutUrl: { type: String, default: null },
  status: { type: String, enum: ['pending', 'paid', 'failed', 'expired', 'cancelled'], default: 'pending', index: true },
  paidAt: { type: Date, default: null },
  expiresAt: { type: Date, required: true }
}, { timestamps: true });

paymentOrderSchema.index(
  { provider: 1, providerTransactionId: 1 },
  { unique: true, partialFilterExpression: { providerTransactionId: { $type: 'string' } } }
);

export default mongoose.model('PaymentOrder', paymentOrderSchema);
