import { Router } from 'express';
import mongoose from 'mongoose';
import { protect, allow } from '../middleware/auth.js';
import { wrap, fail } from '../utils/helpers.js';
import Transaction from '../models/Transaction.js';
import PaymentOrder from '../models/PaymentOrder.js';
import { CREDIT_PACKAGES, PAYMENT_PROVIDERS, ORDER_TTL_MINUTES } from '../config/wallet.js';

const router = Router();
router.use(protect, allow('user'));

router.get('/', wrap(async (req, res) => {
  const [transactions, orders] = await Promise.all([
    Transaction.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(30).lean(),
    PaymentOrder.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(10).lean()
  ]);
  res.json({
    balance: req.user.points,
    packages: CREDIT_PACKAGES,
    providers: PAYMENT_PROVIDERS,
    transactions,
    orders
  });
}));

router.post('/orders', wrap(async (req, res) => {
  const { packageId, provider } = req.body || {};
  const pack = CREDIT_PACKAGES.find((item) => item.id === packageId);
  if (!pack || !PAYMENT_PROVIDERS.includes(provider)) return fail(res, 400, 'INVALID_INPUT');

  const order = await PaymentOrder.create({
    user: req.user._id,
    packageId: pack.id,
    credits: pack.credits,
    amountEGP: pack.priceEGP,
    provider,
    expiresAt: new Date(Date.now() + ORDER_TTL_MINUTES * 60 * 1000)
  });

  // Payment provider credentials/webhook verification are intentionally required
  // before a real checkout URL can be issued or credits can be added.
  res.status(201).json({
    order: {
      id: order._id,
      packageId: order.packageId,
      credits: order.credits,
      amountEGP: order.amountEGP,
      provider: order.provider,
      status: order.status,
      expiresAt: order.expiresAt
    },
    checkoutConfigured: false,
    checkoutUrl: null,
    message: 'PAYMENT_PROVIDER_NOT_CONFIGURED'
  });
}));

router.get('/orders/:id', wrap(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return fail(res, 404, 'NOT_FOUND');
  const order = await PaymentOrder.findOne({ _id: req.params.id, user: req.user._id }).lean();
  if (!order) return fail(res, 404, 'NOT_FOUND');
  res.json({
    id: order._id,
    packageId: order.packageId,
    credits: order.credits,
    amountEGP: order.amountEGP,
    provider: order.provider,
    status: order.status,
    expiresAt: order.expiresAt,
    paidAt: order.paidAt
  });
}));

export default router;
