<script setup>
import { ref, onMounted, watch } from 'vue';
import api from '../../services/api';
const status = ref('pending');
const orders = ref([]);
const err = ref('');
async function load() {
  err.value = '';
  try { orders.value = (await api.get('/admin/payments', { params: { status: status.value } })).data.orders; }
  catch (e) { err.value = e?.response?.data?.code || 'ERROR'; }
}
watch(status, load);
onMounted(load);
</script>
<template>
  <div class="card">
    <div class="tabs"><button v-for="s in ['pending','paid','failed','expired','cancelled']" :key="s" :class="{active:status===s}" @click="status=s">{{s}}</button></div>
    <div v-if="err" class="alert error">{{err}}</div>
    <p v-if="!orders.length" class="muted">—</p>
    <div v-for="o in orders" :key="o._id" class="list-item">
      <div><b>{{o.user?.name}}</b> <span class="muted">{{o.user?.email}}</span><br/>{{o.credits}} credits · <b>{{o.amountEGP}} EGP</b> · {{o.provider}}<br/><span class="muted">Order {{o.reference}} · Provider ref {{o.fawryReference || o.providerOrderId || '—'}}</span></div>
      <span class="badge" :class="o.status==='paid'?'approved':'rejected'">{{o.status}}</span>
    </div>
  </div>
</template>
