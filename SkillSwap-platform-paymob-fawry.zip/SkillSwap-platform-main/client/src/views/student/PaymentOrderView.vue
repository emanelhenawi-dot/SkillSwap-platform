<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
import api, { errCode } from '../../services/api';
const { locale } = useI18n();
const isAr = computed(() => locale.value === 'ar');
const L = (ar, en) => isAr.value ? ar : en;
const route = useRoute();
const router = useRouter();
const order = ref(null);
const error = ref('');
let timer;
const money = v => new Intl.NumberFormat(isAr.value ? 'ar-EG' : 'en-EG', { style: 'currency', currency: 'EGP', maximumFractionDigits: 2 }).format(v || 0);
const providerName = computed(() => order.value?.provider === 'paymob' ? 'Paymob' : 'Fawry');
async function load() {
  try {
    const { data } = await api.get(`/wallet/orders/${route.params.id}`);
    order.value = data.order;
    if (order.value.status !== 'pending') { clearInterval(timer); timer = null; }
    else if (!timer) timer = setInterval(load, 7000);
  } catch (e) { error.value = errCode(e); }
}
function openCheckout() { if (order.value?.checkoutUrl) window.location.assign(order.value.checkoutUrl); }
onMounted(load);
onUnmounted(() => clearInterval(timer));
</script>

<template>
  <section class="page-wrap" v-if="order">
    <div class="page-heading">
      <span class="eyebrow">{{ L('المحفظة / حالة الدفع', 'CREDIT WALLET / PAYMENT STATUS') }}</span>
      <h1>{{ order.status === 'paid' ? L('تم تأكيد الدفع.', 'Payment confirmed.') : order.status === 'pending' ? L('أكملي عملية الدفع.', 'Complete your payment.') : L('حالة طلب الدفع', 'Payment order status') }}</h1>
      <p>{{ L('طريقة الدفع:', 'Payment provider:') }} {{ providerName }}</p>
    </div>
    <div v-if="error" class="alert error">{{ error }}</div>
    <div class="card-panel" style="max-width:680px">
      <span class="eyebrow">{{ order.status.toUpperCase() }}</span>
      <h2>{{ order.credits }} {{ L('نقطة', 'Skill Credits') }} · {{ money(order.amountEGP) }}</h2>
      <p class="muted">{{ L('رقم الطلب:', 'Order reference:') }} <b>{{ order.reference }}</b></p>
      <template v-if="order.status === 'pending'">
        <div v-if="order.provider === 'paymob'" class="soft-note">
          <b>{{ L('الدفع مستضاف وآمن لدى Paymob', 'Secure hosted payment by Paymob') }}</b>
          <p>{{ L('اضغطي على الزر للانتقال إلى صفحة Paymob. بعد إتمام الدفع سنحدّث الرصيد تلقائيًا عند وصول تأكيد موثّق.', 'Continue to Paymob hosted checkout. Your wallet updates automatically after our server receives a verified payment confirmation.') }}</p>
          <button class="btn block" :disabled="!order.checkoutUrl" @click="openCheckout">{{ L('الانتقال إلى Paymob', 'Continue to Paymob') }}</button>
        </div>
        <div v-else class="soft-note">
          <b>{{ L('مرجع الدفع لدى فوري', 'Your Fawry payment reference') }}</b>
          <p style="font-size:28px;font-weight:800;direction:ltr;text-align:start">{{ order.fawryReference || '—' }}</p>
          <p>{{ L('استخدمي المرجع لإتمام الدفع لدى فوري. ستُضاف النقاط بعد وصول إشعار تأكيد الدفع إلى السيرفر.', 'Use this reference to complete payment through Fawry. Credits are added after Fawry sends a verified payment notification.') }}</p>
        </div>
        <p class="muted tiny">{{ L('حالة الطلب تتحدث تلقائيًا. لا تعيدي الدفع إذا كانت العملية قيد المعالجة.', 'This page checks the payment status automatically. Do not pay twice while the order is pending.') }}</p>
      </template>
      <template v-else-if="order.status === 'paid'">
        <div class="alert ok">{{ L(`تمت إضافة ${order.credits} نقطة إلى محفظتك.`, `${order.credits} credits have been added to your wallet.`) }}</div>
      </template>
      <template v-else>
        <div class="alert error">{{ order.reviewNote || L('لم تكتمل عملية الدفع أو انتهت صلاحية الطلب.', 'Payment did not complete or the order expired.') }}</div>
      </template>
      <RouterLink to="/wallet" class="btn block">{{ L('الرجوع للمحفظة', 'Return to wallet') }}</RouterLink>
    </div>
  </section>
</template>
