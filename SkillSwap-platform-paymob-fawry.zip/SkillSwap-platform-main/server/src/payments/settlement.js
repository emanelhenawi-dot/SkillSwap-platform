import mongoose from 'mongoose';
import PaymentOrder from '../models/PaymentOrder.js';
import User from '../models/User.js';
import Transaction from '../models/Transaction.js';
import { sendMail } from '../utils/mailer.js';

export async function settlePaidOrder({ order, transactionId, provider }) {
  const session = await mongoose.startSession();
  let settled = false;
  try {
    await session.withTransaction(async () => {
      const fresh = await PaymentOrder.findOneAndUpdate(
        { _id: order._id, provider, status: 'pending', providerTransactionId: null },
        { $set: { status: 'paid', providerTransactionId: String(transactionId), paidAt: new Date() } },
        { new: true, session }
      );
      if (!fresh) return;
      await User.updateOne({ _id: fresh.user }, { $inc: { points: fresh.credits } }, { session });
      await Transaction.create([{ user: fresh.user, type: 'purchase', amount: fresh.credits, note: `Order ${fresh.reference} (${provider})` }], { session });
      settled = true;
    });
  } finally { await session.endSession(); }

  if (settled) {
    const paidOrder = await PaymentOrder.findById(order._id).populate('user', 'email name');
    if (paidOrder?.user?.email) {
      await sendMail({
        to: paidOrder.user.email,
        subject: 'SkillSwap | Payment confirmed',
        html: `<div style="font-family:Arial,sans-serif"><h2>SkillSwap</h2><p>Hello ${String(paidOrder.user.name || 'Student').replace(/[<>]/g, '')},</p><p>Your payment was confirmed and ${paidOrder.credits} Skill Credits were added to your wallet.</p><p>Order: ${paidOrder.reference}</p></div>`,
      });
    }
  }
  return settled;
}
