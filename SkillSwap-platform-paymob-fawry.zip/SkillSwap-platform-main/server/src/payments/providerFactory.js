import crypto from 'crypto';
import { PAYMENT_PROVIDERS } from '../config/wallet.js';

const required = (name) => {
  const value = process.env[name];
  if (!value) throw new Error(`${name}_NOT_CONFIGURED`);
  return value;
};
const jsonFetch = async (url, options) => {
  const response = await fetch(url, { ...options, signal: AbortSignal.timeout(20000) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(data.detail || data.message || `PAYMENT_PROVIDER_HTTP_${response.status}`);
    err.status = 502;
    throw err;
  }
  return data;
};
const egPhone = (phone = '') => {
  const digits = String(phone).replace(/[^0-9+]/g, '');
  if (/^01[0125][0-9]{8}$/.test(digits)) return `+2${digits}`;
  if (/^\+201[0125][0-9]{8}$/.test(digits)) return digits;
  return '+201000000000';
};
const names = (name = 'SkillSwap Student') => {
  const parts = String(name).trim().split(/\s+/);
  return { first_name: parts[0] || 'Student', last_name: parts.slice(1).join(' ') || 'User' };
};

class PaymobProvider {
  async createCheckout(order, user) {
    const secret = required('PAYMOB_SECRET_KEY');
    const publicKey = required('PAYMOB_PUBLIC_KEY');
    const integrationIds = required('PAYMOB_INTEGRATION_IDS').split(',').map(v => Number(v.trim())).filter(Number.isInteger);
    if (!integrationIds.length) throw new Error('PAYMOB_INTEGRATION_IDS_INVALID');
    const base = process.env.PAYMOB_BASE_URL || 'https://accept.paymob.com';
    const n = names(user.name);
    const payload = {
      amount: Math.round(order.amountEGP * 100),
      currency: 'EGP',
      payment_methods: integrationIds,
      items: [{ name: `SkillSwap ${order.packageId} credits`, amount: Math.round(order.amountEGP * 100), quantity: 1 }],
      billing_data: {
        ...n, email: user.email, phone_number: egPhone(user.phone),
        street: 'NA', building: 'NA', floor: 'NA', apartment: 'NA', city: 'Damietta', state: 'Damietta', country: 'EG', postal_code: 'NA'
      },
      special_reference: order.reference,
      expiration: 3600,
      notification_url: required('PAYMOB_NOTIFICATION_URL'),
      redirection_url: `${required('CLIENT_URL')}/wallet/orders/${order._id}?payment=return`,
    };
    const data = await jsonFetch(`${base}/v1/intention/`, {
      method: 'POST', headers: { Authorization: `Token ${secret}`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    if (!data.client_secret || !data.intention_order_id) throw new Error('PAYMOB_INVALID_INTENTION_RESPONSE');
    return {
      providerOrderId: String(data.intention_order_id),
      checkoutUrl: `${base}/unifiedcheckout/?publicKey=${encodeURIComponent(publicKey)}&clientSecret=${encodeURIComponent(data.client_secret)}`,
    };
  }
}

class FawryProvider {
  async createCheckout(order, user) {
    const merchantCode = required('FAWRY_MERCHANT_CODE');
    const secureKey = required('FAWRY_SECURE_KEY');
    const apiUrl = process.env.FAWRY_CHARGE_URL || 'https://atfawry.fawrystaging.com/ECommerceWeb/api/payments/charge';
    const merchantRefNum = String(Date.now()) + String(crypto.randomInt(100, 999));
    const customerProfileId = String(user._id);
    const paymentMethod = 'PayAtFawry';
    const amount = Number(order.amountEGP).toFixed(2);
    const signature = crypto.createHash('sha256').update(`${merchantCode}${merchantRefNum}${customerProfileId}${paymentMethod}${amount}${secureKey}`).digest('hex');
    const payload = {
      merchantCode, merchantRefNum, customerProfileId,
      customerName: user.name || 'SkillSwap Student',
      customerMobile: String(user.phone || '01000000000').replace(/^\+20/, '0'),
      customerEmail: user.email,
      amount, currencyCode: 'EGP', paymentMethod, description: `SkillSwap ${order.packageId} credits`,
      language: 'en-gb',
      paymentExpiry: Date.now() + 60 * 60 * 1000,
      orderWebHookUrl: required('FAWRY_NOTIFICATION_URL'),
      chargeItems: [{ itemId: order.packageId, description: `SkillSwap ${order.credits} credits`, price: amount, quantity: 1 }],
      signature,
    };
    const data = await jsonFetch(apiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (Number(data.statusCode) !== 200 || !data.referenceNumber) {
      const err = new Error(data.statusDescription || 'FAWRY_CHARGE_FAILED'); err.status = 502; throw err;
    }
    return { providerOrderId: merchantRefNum, fawryReference: String(data.referenceNumber) };
  }
}

export function getPaymentProvider(name) {
  if (!PAYMENT_PROVIDERS.includes(name)) throw new Error('UNSUPPORTED_PAYMENT_PROVIDER');
  return name === 'paymob' ? new PaymobProvider() : new FawryProvider();
}
