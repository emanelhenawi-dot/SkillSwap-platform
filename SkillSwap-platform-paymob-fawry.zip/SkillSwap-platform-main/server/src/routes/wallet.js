import { Router } from 'express';
import crypto from 'crypto';
import mongoose from 'mongoose';
import rateLimit from 'express-rate-limit';
import { protect, allow } from '../middleware/auth.js';
import { wrap, fail } from '../utils/helpers.js';
import Transaction from '../models/Transaction.js';
import PaymentOrder from '../models/PaymentOrder.js';
import { CREDIT_PACKAGES, PAYMENT_PROVIDERS, ORDER_TTL_MINUTES } from '../config/wallet.js';
import { getPaymentProvider } from '../payments/providerFactory.js';

const router = Router();
router.use(protect, allow('user'));
const submitLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 8, standardHeaders: true, legacyHeaders: false, keyGenerator: req => String(req.user._id) });
const pub = o => ({
  id: o._id, packageId: o.packageId, credits: o.credits, amountEGP: o.amountEGP, provider: o.provider,
  status: o.status, reference: o.reference, providerOrderId: o.providerOrderId,
  checkoutUrl: o.checkoutUrl, fawryReference: o.fawryReference, expiresAt: o.expiresAt, paidAt: o.paidAt, reviewNote: o.reviewNote,
});

router.get('/', wrap(async (req, res) => {
  const [transactions, orders] = await Promise.all([
    Transaction.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(30).lean(),
    PaymentOrder.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(10).lean(),
  ]);
  res.json({ balance: req.user.points, packages: CREDIT_PACKAGES, providers: PAYMENT_PROVIDERS, transactions, orders: orders.map(pub) });
}));

router.post('/orders', submitLimiter, wrap(async (req, res) => {
  const { packageId, provider } = req.body || {};
  const pack = CREDIT_PACKAGES.find(p => p.id === packageId);
  if (!pack || !PAYMENT_PROVIDERS.includes(provider)) return fail(res, 400, 'INVALID_INPUT');
  await PaymentOrder.updateMany({ user: req.user._id, status: 'pending', expiresAt: { $lt: new Date() } }, { $set: { status: 'expired' } });
  const open = await PaymentOrder.countDocuments({ user: req.user._id, status: 'pending' });
  if (open >= 3) return fail(res, 429, 'TOO_MANY_OPEN_ORDERS');

  const order = await PaymentOrder.create({
    user: req.user._id, packageId: pack.id, credits: pack.credits, amountEGP: pack.priceEGP, provider,
    reference: `SS-${crypto.randomBytes(8).toString('hex').toUpperCase()}`,
    expiresAt: new Date(Date.now() + ORDER_TTL_MINUTES * 60 * 1000),
  });
  try {
    const gateway = getPaymentProvider(provider);
    const checkout = await gateway.createCheckout(order, req.user);
    order.providerOrderId = checkout.providerOrderId;
    order.checkoutUrl = checkout.checkoutUrl || null;
    order.fawryReference = checkout.fawryReference || null;
    await order.save();
    res.status(201).json({ order: pub(order) });
  } catch (error) {
    await PaymentOrder.updateOne({ _id: order._id, status: 'pending' }, { $set: { status: 'failed', reviewNote: 'Could not create provider checkout.' } });
    const code = /NOT_CONFIGURED|INVALID/.test(error.message) ? error.message : 'PAYMENT_PROVIDER_ERROR';
    return fail(res, error.status || 503, code);
  }
}));

router.get('/orders/:id', wrap(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return fail(res, 404, 'NOT_FOUND');
  const order = await PaymentOrder.findOne({ _id: req.params.id, user: req.user._id });
  if (!order) return fail(res, 404, 'NOT_FOUND');
  if (order.status === 'pending' && order.expiresAt < new Date()) { order.status = 'expired'; await order.save(); }
  res.json({ order: pub(order) });
}));

router.post('/orders/:id/cancel', wrap(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return fail(res, 404, 'NOT_FOUND');
  const order = await PaymentOrder.findOneAndUpdate(
    { _id: req.params.id, user: req.user._id, provider: { $in: PAYMENT_PROVIDERS }, status: 'pending' },
    { $set: { status: 'cancelled' } }, { new: true }
  );
  if (!order) return fail(res, 409, 'ORDER_NOT_PENDING');
  res.json({ order: pub(order) });
}));

export default router;
