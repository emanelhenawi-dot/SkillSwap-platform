import { Router } from 'express';
import crypto from 'crypto';
import PaymentOrder from '../models/PaymentOrder.js';
import { settlePaidOrder } from '../payments/settlement.js';

const router = Router();
const safeEqual = (a, b) => {
  const x = Buffer.from(String(a || ''), 'utf8');
  const y = Buffer.from(String(b || ''), 'utf8');
  return x.length > 0 && x.length === y.length && crypto.timingSafeEqual(x, y);
};

function verifyPaymob(obj, received) {
  const fields = [
    obj.amount_cents, obj.created_at, obj.currency, obj.error_occured, obj.has_parent_transaction,
    obj.id, obj.integration_id, obj.is_3d_secure, obj.is_auth, obj.is_capture, obj.is_refunded,
    obj.is_standalone_payment, obj.is_voided, obj.order?.id, obj.owner, obj.pending,
    obj.source_data?.pan, obj.source_data?.sub_type, obj.source_data?.type, obj.success,
  ];
  if (fields.some(v => v === undefined)) return false;
  const expected = crypto.createHmac('sha512', process.env.PAYMOB_HMAC_SECRET).update(fields.map(v => v === null ? '' : String(v)).join('')).digest('hex');
  return safeEqual(expected, received);
}

router.post('/paymob', async (req, res) => {
  try {
    const obj = req.body?.obj;
    if (!process.env.PAYMOB_HMAC_SECRET || !obj || !verifyPaymob(obj, req.query.hmac)) return res.status(401).json({ code: 'INVALID_SIGNATURE' });
    const order = await PaymentOrder.findOne({ provider: 'paymob', providerOrderId: String(obj.order?.id) });
    if (!order) return res.status(200).json({ received: true, ignored: true });
    const allowedIntegrations = String(process.env.PAYMOB_INTEGRATION_IDS || '').split(',').map(v => Number(v.trim())).filter(Number.isInteger);
    const integrationMatches = allowedIntegrations.includes(Number(obj.integration_id));
    const amountMatches = Number(obj.amount_cents) === Math.round(order.amountEGP * 100);
    const successful = obj.success === true && obj.pending === false && obj.error_occured === false && obj.is_refunded !== true && obj.currency === 'EGP';
    if (successful && amountMatches && integrationMatches) await settlePaidOrder({ order, transactionId: obj.id, provider: 'paymob' });
    else if (obj.success === false && order.status === 'pending') await PaymentOrder.updateOne({ _id: order._id, status: 'pending' }, { $set: { status: 'failed', reviewNote: 'Payment was not successful.' } });
    return res.status(200).json({ received: true });
  } catch (error) {
    console.error('Paymob webhook error:', error.message);
    return res.status(500).json({ code: 'WEBHOOK_PROCESSING_FAILED' });
  }
});

router.post('/fawry', async (req, res) => {
  try {
    const body = req.body || {};
    const secureKey = process.env.FAWRY_SECURE_KEY;
    if (!secureKey || !body.messageSignature) return res.status(401).json({ code: 'INVALID_SIGNATURE' });
    const merchantRef = body.merchantRefNum ?? body.merchantRefNumber;
    const amount = Number(body.paymentAmount).toFixed(2);
    const orderAmount = Number(body.orderAmount).toFixed(2);
    const signed = `${body.fawryRefNumber || ''}${merchantRef || ''}${amount}${orderAmount}${body.orderStatus || ''}${body.paymentMethod || ''}${body.paymentRefrenceNumber || ''}${secureKey}`;
    const expected = crypto.createHash('sha256').update(signed).digest('hex');
    if (!safeEqual(expected.toLowerCase(), String(body.messageSignature).toLowerCase())) return res.status(401).json({ code: 'INVALID_SIGNATURE' });
    const order = await PaymentOrder.findOne({ provider: 'fawry', providerOrderId: String(merchantRef) });
    if (!order) return res.status(200).json({ received: true, ignored: true });
    const amountMatches = Number(body.orderAmount) === Number(order.amountEGP) && Number(body.paymentAmount) >= Number(order.amountEGP);
    if (body.orderStatus === 'PAID' && amountMatches) {
      await settlePaidOrder({ order, transactionId: body.paymentRefrenceNumber || body.fawryRefNumber, provider: 'fawry' });
    } else if (['FAILED', 'CANCELED', 'EXPIRED'].includes(body.orderStatus) && order.status === 'pending') {
      await PaymentOrder.updateOne({ _id: order._id, status: 'pending' }, { $set: { status: 'failed', reviewNote: `Fawry status: ${body.orderStatus}` } });
    }
    return res.status(200).json({ received: true });
  } catch (error) {
    console.error('Fawry webhook error:', error.message);
    return res.status(500).json({ code: 'WEBHOOK_PROCESSING_FAILED' });
  }
});

export default router;
