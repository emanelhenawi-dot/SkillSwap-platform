import mongoose from 'mongoose';
const { Schema } = mongoose;

const paymentOrderSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  packageId: { type: String, required: true },
  credits: { type: Number, required: true, min: 1 },
  amountEGP: { type: Number, required: true, min: 1 },
  provider: { type: String, enum: ['paymob', 'fawry'], required: true },
  reference: { type: String, required: true, unique: true },
  // pending: waiting for provider settlement; paid: verified webhook received.
  status: { type: String, enum: ['pending', 'submitted', 'paid', 'failed', 'expired', 'cancelled'], default: 'pending', index: true },
  providerOrderId: { type: String, default: null, index: true },
  providerTransactionId: { type: String, default: null },
  checkoutUrl: { type: String, default: null },
  fawryReference: { type: String, default: null },
  paidAt: { type: Date, default: null },
  reviewNote: String,
  expiresAt: { type: Date, required: true },
}, { timestamps: true });

paymentOrderSchema.index(
  { provider: 1, providerOrderId: 1 },
  { unique: true, partialFilterExpression: { providerOrderId: { $type: 'string' } } }
);
paymentOrderSchema.index(
  { provider: 1, providerTransactionId: 1 },
  { unique: true, partialFilterExpression: { providerTransactionId: { $type: 'string' } } }
);

export default mongoose.model('PaymentOrder', paymentOrderSchema);
