export const CREDIT_PACKAGES = Object.freeze([
  { id: 'starter', name: 'Starter Pack', credits: 5, priceEGP: 140 },
  { id: 'scholar', name: 'Scholar Pack', credits: 12, priceEGP: 310 },
  { id: 'master', name: 'Master Pack', credits: 25, priceEGP: 600 },
]);

// Online gateways enabled for this build. Keep all credentials on the server.
export const PAYMENT_PROVIDERS = Object.freeze(['paymob', 'fawry']);
export const ORDER_TTL_MINUTES = 60;
