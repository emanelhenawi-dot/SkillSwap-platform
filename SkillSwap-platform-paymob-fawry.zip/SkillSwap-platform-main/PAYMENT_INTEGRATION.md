# SkillSwap Paymob + Fawry integration

This branch enables two hosted payment providers. The app never receives card numbers or CVV values.

## What is implemented
- `POST /api/wallet/orders` creates a package order and requests a Paymob intention or FawryPay reference.
- Paymob uses the Intention API and Unified Checkout.
- Fawry uses the server-side charge/reference flow.
- `POST /api/webhooks/paymob` verifies the SHA-512 HMAC before accepting a transaction callback.
- `POST /api/webhooks/fawry` verifies the SHA-256 Server Notification V2 signature.
- Wallet credits are granted only from verified server callbacks, with a MongoDB transaction and provider transaction ID uniqueness.
- `/wallet/orders/:id` polls for provider confirmation. The browser redirect is not treated as proof of payment.
- The admin payment panel is read-only for gateway transactions; no manual button can mint credits.

## Setup
1. Use Node.js 20+ and MongoDB Atlas or a local MongoDB replica set. Settlement uses MongoDB transactions; standalone MongoDB does not support them.
2. Copy `server/.env.example` to `server/.env` and fill TEST/STAGING credentials only.
3. Configure both callback URLs in the merchant dashboards as public HTTPS endpoints.
4. Ensure the Paymob notification URL is the transaction processed callback, not the browser response redirect.
5. Ensure Fawry is configured to send Server Notification V2 to `/api/webhooks/fawry`.
6. Run `npm install` in `server` and `npm run dev`.
7. Run `npm install` in `client` and `npm run dev`.
8. Test a successful payment, failed payment, duplicate callback, amount mismatch, and expired order before any live launch.

## Required credentials
- Paymob: Secret Key, Public Key, one or more Integration IDs, HMAC Secret.
- FawryPay: Merchant Code and Secure Key, with staging enabled for testing.

Never commit `.env`, expose secret keys in Vue/Vite variables, or trust a `success=true` query parameter from a redirect. For real-money activation, a verified merchant account and an adult/legal account owner must complete the provider onboarding and review the terms, fees, refund, and safeguarding obligations.

## Notes
- Package prices and point amounts remain the values already defined in `server/src/config/wallet.js`; update them only after the project team approves the economy.
- If your Fawry merchant account has a different staging/production endpoint or a different payment product, set `FAWRY_CHARGE_URL` to the exact endpoint supplied by FawryPay.
- The Fawry callback signature and Paymob callback HMAC must be checked against the exact notification version enabled on the merchant account before going live.
